function sw(hold_value)
% sw: switch data acquisition modes (detects amplifier telegraphs)
% Usage
%     sw <cr> waits for user to change amplifier settings, the loads
%             the appropriate default stimuli for that mode.
%
%     sw HOLD automatically loads the specified holding current or
%             voltage when the stimulus parameters are loaded.

% function to switch the data acquisition mode
% sets up the watch operation, and lets sense_mode
% get called when the changes occur.
%
% Basic  operation for Axon Instruments AxoPatch 200 series amplifiers:
% 1. find the current mode (assumed to be either I or V)
% 2. set a threshold accordingly, so that when the switch is moved to the
%    track position, the alternate stimulus file is loaded
% 3. that's all. When the switch is moved to the next position, the correct
%    drive should be applied to the amplifier.
%
% Modified 9/27/01 SCM - added Data field to AmpStatus to prevent voltage estimate.
%
% Modified 9/28/01 SCM - detect entry into I = 0 mode, not exit previous mode
% this corrects for switching between normal & fast CC modes
% this does not require changing stim files
%
% Modified 10/9/01 SCM - allow holding value to be passed as a parameter
% the specified holding level is automatically set when the new stim file is loaded

% Modified 7/11/03 SCM - added Multiclamp amplifier code

% default parameters
wait_time = 10;  % maximum time to wait for mode change

% routine can only be called when NIDAQ registered
global ACQ_DEVICE CONFIG
if (strcmp(ACQ_DEVICE, 'nidaq'))
    amplifier_string = lower(CONFIG.Amplifier.v);
else
    QueMessage('sw: NIDAQ not registered', 1);
    return
end

% check for holding level
% convert value to numeric if needed
% may be string when called from command line
if (nargin < 1)
    hold_level = [];
elseif (isnumeric(hold_value))
    hold_level = hold_value;
else
    hold_level = str2num(hold_value);
end

% read the current value
% cannot start in I = 0 mode!
AmpStatus = telegraph;
old_mode = AmpStatus.Mode;
if (strcmp(AmpStatus.Mode, '0'))
    QueMessage('sw: caught in track mode, reset and try again', 1);
    return
elseif (strcmp(AmpStatus.Mode, 'X'))
    QueMessage('sw: cannot read amplifier mode', 1);
    return
end

switch (amplifier_string)
    
    case {'axopatch', 'axopatch200', 'axopatch200a', 'axopatch200b'}
        % default parameters for Axopatch mode
        mode_chan = 1;  % index of mode telegraph in AmpStatus.Data field
        mode_tel = [6 4 3 2 1]; % voltages in various modes
        mode_volt = mode_tel(3);  %  voltage in I = 0 mode
        watch_chan = [13]; % default ACH for mode input
        watch_range = [-10 10]; % need full range
        
        % create AI object if needed
        global DEVICE_ID WAI
        if (~validobj(WAI, 'analoginput'))
            fprintf(2, 'Creating %s Watch Input object\n', upper(ACQ_DEVICE));
            WAI = analoginput(ACQ_DEVICE, DEVICE_ID);
        end
        stop(WAI);
        delete(WAI.channel);
        
        % configure watch input object
        % set channels, define acquisition duration
        % waits for voltage to change
        % 7/11/03 SCM - add TimerFcn to replace timeout
        set(WAI, 'InputType', 'NonReferencedSingleEnded');
        set(WAI, 'DriveAISenseToGround', 'On');
        ai_chans = addchannel(WAI, watch_chan);
        set(ai_chans, 'InputRange', watch_range);
        set(WAI, 'SamplesPerTrigger', 10);
        set(WAI, 'SampleRate', 1000); % takes 100 usec to sample...
        set(WAI, 'TimerFcn', {@sense_mode, old_mode, hold_level});
        set(WAI, 'TimerPeriod', wait_time);
        set(WAI, 'TriggerChannel', ai_chans(1));
        set(WAI, 'TriggerType', 'Software');
        set(WAI, 'TriggerCondition', 'Entering');
        %set(WAI, 'TriggerType', 'HwAnalogChannel');
        %set(WAI, 'TriggerCondition', 'InsideRegion');
        set(WAI, 'TriggerConditionValue', [(mode_volt - 0.5) (mode_volt + 0.5)]);
        set(WAI, 'TriggerDelay', 0.02); % allow 20 msec to settle
        set(WAI, 'TriggerFcn', {@sense_mode, old_mode, hold_level}); % pass the current mode to trigger routine
        
        % starts waiting for the voltage to cross the threshold
        % we just return at this point. Seems that the callback can't occur until we do.
        start(WAI);
        QueMessage('Waiting for amplifier mode change', 1);
        
    case {'multiclamp', 'multiclamp700a', 'multiclamp700', 'multiclamp_both'}
        
        % call MCSWITCH MEX DLL
        % will respond when mode changes or timeout occurs
        QueMessage('Waiting for amplifier mode change', 1);
        [mode_flag, old_mode, new_mode] = mcswitch(1, 0, 1, wait_time);
        
        % convert amplifier mode
        switch (old_mode)
            case 'V-Clamp' % voltage clamp
                old_mode = 'V';
            case 'I-Clamp'  % current clamp
                old_mode = 'I';
            case 'I = 0'    % I = 0
                old_mode = '0';
            otherwise       % unknown
                old_mode = 'X';
        end
        
        % check for timeout or mode change
        % provide dummy event for SENSE_MODE
        if (mode_flag)
            event.Type = 'trigger';
        else
            event.Type = 'timer';
        end
        sense_mode([], event, old_mode, hold_level);
        
    otherwise
        QueMessage(['sw: invalid mode change for ' amplifier_string], 1);
        return
end
return
